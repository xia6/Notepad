import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.charset.Charset;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

public class Notepad extends JFrame implements ActionListener, DocumentListener {
    JTextPane textPane;
    JFrame frame;
    Charset currentCharset = Charset.forName("UTF-8");
    JLabel statusBar;  // 状态栏
    JLabel charCountLabel;  // 显示字符数
    JTextField searchField;  // 查找文本框

    public Notepad() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 创建框架
        frame = new JFrame("记事本");
        textPane = new JTextPane();
        textPane.setFont(new Font("SansSerif", Font.PLAIN, 18));  // 设置默认字体，增大字号
        textPane.setBackground(new Color(245, 245, 245));  // 设置背景颜色
        textPane.getDocument().addDocumentListener(this);  // 添加字符监听

        // 创建菜单栏
        JMenuBar menuBar = new JMenuBar();
        menuBar.setFont(new Font("SansSerif", Font.PLAIN, 16));  // 增大菜单栏字体

        // 创建文件菜单
        JMenu fileMenu = new JMenu("文件");
        fileMenu.setFont(new Font("SansSerif", Font.PLAIN, 16));  // 增大菜单项字体

        JMenuItem newMenuItem = new JMenuItem("新建");
        newMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));  // 增大菜单项字体
        JMenuItem openMenuItem = new JMenuItem("打开");
        openMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem saveMenuItem = new JMenuItem("保存");
        saveMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem exitMenuItem = new JMenuItem("退出");
        exitMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));

        newMenuItem.addActionListener(this);
        openMenuItem.addActionListener(this);
        saveMenuItem.addActionListener(this);
        exitMenuItem.addActionListener(this);

        fileMenu.add(newMenuItem);
        fileMenu.add(openMenuItem);
        fileMenu.add(saveMenuItem);
        fileMenu.add(exitMenuItem);

        JMenu formatMenu = new JMenu("格式");
        formatMenu.setFont(new Font("SansSerif", Font.PLAIN, 16));

        JMenuItem fontMenuItem = new JMenuItem("字体");
        fontMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem colorMenuItem = new JMenuItem("颜色");
        colorMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem insertImageMenuItem = new JMenuItem("插入图片");
        insertImageMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));

        fontMenuItem.addActionListener(this);
        colorMenuItem.addActionListener(this);
        insertImageMenuItem.addActionListener(this);

        formatMenu.add(fontMenuItem);
        formatMenu.add(colorMenuItem);
        formatMenu.add(insertImageMenuItem);

        JMenu charsetMenu = new JMenu("字符集");
        charsetMenu.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem utf8MenuItem = new JMenuItem("UTF-8");
        utf8MenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem unicode32MenuItem = new JMenuItem("Unicode32");
        unicode32MenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem gbk2312MenuItem = new JMenuItem("GBK2312");
        gbk2312MenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem asciiMenuItem = new JMenuItem("ASCII");
        asciiMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));

        utf8MenuItem.addActionListener(this);
        unicode32MenuItem.addActionListener(this);
        gbk2312MenuItem.addActionListener(this);
        asciiMenuItem.addActionListener(this);

        charsetMenu.add(utf8MenuItem);
        charsetMenu.add(unicode32MenuItem);
        charsetMenu.add(gbk2312MenuItem);
        charsetMenu.add(asciiMenuItem);

        JMenu editMenu = new JMenu("编辑");
        editMenu.setFont(new Font("SansSerif", Font.PLAIN, 16));
        JMenuItem findMenuItem = new JMenuItem("查找");
        findMenuItem.setFont(new Font("SansSerif", Font.PLAIN, 16));
        findMenuItem.addActionListener(this);
        editMenu.add(findMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(formatMenu);
        menuBar.add(charsetMenu);
        menuBar.add(editMenu);

        frame.setJMenuBar(menuBar);

        frame.add(new JScrollPane(textPane), BorderLayout.CENTER);

        JPanel searchPanel = new JPanel(new BorderLayout());
        searchField = new JTextField(20);
        searchField.setFont(new Font("SansSerif", Font.PLAIN, 16));  // 设置查找框的字体大小
        JButton searchButton = new JButton("查找");
        searchButton.setFont(new Font("SansSerif", Font.PLAIN, 16));  // 设置按钮字体大小
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);
        frame.add(searchPanel, BorderLayout.NORTH);

        JPanel statusPanel = new JPanel(new BorderLayout());
        statusBar = new JLabel("UTF-8 编码", JLabel.LEFT);
        statusBar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        statusBar.setFont(new Font("SansSerif", Font.PLAIN, 16));  // 增大状态栏字体
        statusPanel.add(statusBar, BorderLayout.WEST);

        charCountLabel = new JLabel("字符数: 0");
        charCountLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));  // 增大字符统计的字体
        statusPanel.add(charCountLabel, BorderLayout.EAST);
        frame.add(statusPanel, BorderLayout.SOUTH);

        frame.setSize(900, 700);  // 增大窗口的尺寸
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        switch (command) {
            case "新建":
                textPane.setText("");
                break;
            case "打开":
                openFile();
                break;
            case "保存":
                saveFile();
                break;
            case "退出":
                System.exit(0);
                break;
            case "字体":
                changeFont();
                break;
            case "颜色":
                changeColor();
                break;
            case "插入图片":
                insertAndResizeImage();
                break;
            case "查找":
                findText();
                break;
            case "UTF-8":
                currentCharset = Charset.forName("UTF-8");
                statusBar.setText("UTF-8 编码");
                break;
            case "Unicode32":
                currentCharset = Charset.forName("UTF-32");
                statusBar.setText("Unicode32 编码");
                break;
            case "GBK2312":
                currentCharset = Charset.forName("GB2312");
                statusBar.setText("GBK2312 编码");
                break;
            case "ASCII":
                currentCharset = Charset.forName("US-ASCII");
                statusBar.setText("ASCII 编码");
                break;
        }
    }

    @Override
    public void insertUpdate(DocumentEvent e) {
        updateCharCount();
    }

    @Override
    public void removeUpdate(DocumentEvent e) {
        updateCharCount();
    }

    @Override
    public void changedUpdate(DocumentEvent e) {
        updateCharCount();
    }

    private void updateCharCount() {
        int charCount = textPane.getDocument().getLength();
        charCountLabel.setText("字符数: " + charCount);
    }

    private void findText() {
        String searchText = searchField.getText();
        String documentText = textPane.getText();
        if (!searchText.isEmpty()) {
            int index = documentText.indexOf(searchText);
            if (index >= 0) {
                textPane.setSelectionStart(index);
                textPane.setSelectionEnd(index + searchText.length());
                textPane.requestFocus();
            } else {
                JOptionPane.showMessageDialog(frame, "找不到: " + searchText);
            }
        }
    }

    private void changeFont() {
        String[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        String selectedFont = (String) JOptionPane.showInputDialog(frame, "选择字体:", "字体", JOptionPane.PLAIN_MESSAGE, null, fonts, textPane.getFont().getFamily());
        if (selectedFont != null) {
            int fontSize = Integer.parseInt(JOptionPane.showInputDialog(frame, "输入字体大小:", textPane.getFont().getSize()));
            textPane.setFont(new Font(selectedFont, Font.PLAIN, fontSize));
        }
    }

    private void changeColor() {
        Color selectedColor = JColorChooser.showDialog(frame, "选择颜色", textPane.getForeground());
        if (selectedColor != null) {
            textPane.setForeground(selectedColor);
        }
    }

    private void openFile() {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), currentCharset))) {
                textPane.read(reader, null);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void saveFile() {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), currentCharset))) {
                textPane.write(writer);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    private void insertAndResizeImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setAccessory(new ImagePreview(fileChooser));  // 添加图片预览功能
        if (fileChooser.showOpenDialog(frame) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            try {
                ImageIcon imageIcon = new ImageIcon(file.getPath());
                Image image = imageIcon.getImage();
                JLabel imageLabel = new JLabel(imageIcon);
                imageLabel.setCursor(Cursor.getPredefinedCursor(Cursor.SE_RESIZE_CURSOR));

                MouseAdapter resizeListener = new MouseAdapter() {
                    Point initialClick;

                    @Override
                    public void mousePressed(MouseEvent e) {
                        initialClick = e.getPoint();
                    }

                    @Override
                    public void mouseDragged(MouseEvent e) {
                        int widthChange = e.getX() - initialClick.x;
                        int heightChange = e.getY() - initialClick.y;
                        int newWidth = imageLabel.getWidth() + widthChange;
                        int newHeight = imageLabel.getHeight() + heightChange;

                        if (newWidth > 50 && newHeight > 50) {
                            imageLabel.setIcon(new ImageIcon(image.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH)));
                            imageLabel.setSize(newWidth, newHeight);
                            frame.revalidate();
                        }
                    }
                };

                imageLabel.addMouseListener(resizeListener);
                imageLabel.addMouseMotionListener(resizeListener);

                StyledDocument doc = textPane.getStyledDocument();
                Style style = textPane.addStyle("imageStyle", null);
                StyleConstants.setComponent(style, imageLabel);
                doc.insertString(doc.getLength(), " ", style);

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    // 图片预览类
    class ImagePreview extends JComponent implements PropertyChangeListener {
        private static final int PREVIEW_WIDTH = 100;
        private static final int PREVIEW_HEIGHT = 100;
        private ImageIcon thumbnail = null;
        private File file = null;

        public ImagePreview(JFileChooser fileChooser) {
            setPreferredSize(new Dimension(PREVIEW_WIDTH, PREVIEW_HEIGHT));
            fileChooser.addPropertyChangeListener(this);
        }

        public void loadImage() {
            if (file == null) {
                thumbnail = null;
                return;
            }

            ImageIcon tmpIcon = new ImageIcon(file.getPath());
            if (tmpIcon != null) {
                if (tmpIcon.getIconWidth() > PREVIEW_WIDTH) {
                    thumbnail = new ImageIcon(tmpIcon.getImage().getScaledInstance(PREVIEW_WIDTH, -1, Image.SCALE_SMOOTH));
                } else {
                    thumbnail = tmpIcon;
                }
            }
        }

        @Override
        public void propertyChange(PropertyChangeEvent evt) {
            boolean update = false;
            String prop = evt.getPropertyName();

            if (JFileChooser.SELECTED_FILE_CHANGED_PROPERTY.equals(prop)) {
                file = (File) evt.getNewValue();
                update = true;
            }

            if (update) {
                thumbnail = null;
                if (isShowing()) {
                    loadImage();
                    repaint();
                }
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (thumbnail != null) {
                int x = getWidth() / 2 - thumbnail.getIconWidth() / 2;
                int y = getHeight() / 2 - thumbnail.getIconHeight() / 2;
                if (y < 0) y = 0;

                thumbnail.paintIcon(this, g, x, y);
            }
        }
    }

    public static void main(String[] args) {
        new Notepad();
    }
}
